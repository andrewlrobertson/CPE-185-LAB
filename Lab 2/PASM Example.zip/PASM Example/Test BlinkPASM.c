/*
  libblinkpasm.c
  Test harness for the blinkpasm library, which can launch multiple
  instances of the light blinking process.  
*/

#include "simpletools.h"                      // Library includes
#include "blinkpasm.h"

blink_t *blink[2];                            // Declare two instances

int main()                                    // Main function
{
  blink[0] = blinkpasm_start(26, CLKFREQ/2);  // Launch instances, get handles
  blink[1] = blinkpasm_start(27, CLKFREQ/3);       
  
  int reps = 0;

  while(1)                                    // Test loop
  {
    print("%c P3 = %d, P4 = %d \n",           // Display button states
          HOME, blinkpasm_getState(blink[0]),
                blinkpasm_getState(blink[1]));
    pause(100);                               // Update dispaly every 1/10 seconds
    if(reps++ == 25)                          // At 2.5 seconds,
      blinkpasm_setRate(blink[0], CLKFREQ/8); // ...increase P26 rate
  }  
}


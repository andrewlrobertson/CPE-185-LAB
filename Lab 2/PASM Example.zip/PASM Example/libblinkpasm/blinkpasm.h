/*
  buttonblinkerB.h
  Header file for the buttonblinkerB library
*/

#ifndef __BLINKPASM_H
#define __BLINKPASM_H

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct blinkpasm_struct               // Structure contains varaibles
{                                             // for cogs to share + cog & stack
  volatile int maskLed;                       // Shared
  volatile int stateLed;            
  volatile int halfPeriod;
  int cog;                                    // Remembers cog for btnblink_stop 
} blink_t;                                    // Data type for struct

blink_t *blinkpasm_start(int ledpin, 
                         int cycleTicks);

void blinkpasm_stop(blink_t *device);

int blinkpasm_getState(blink_t *device);

void blinkpasm_setRate(blink_t *device, 
                       int cycleTicks);

#ifdef __cplusplus
}
#endif
/* __cplusplus */
#endif 
/* __LEDBTN_H */

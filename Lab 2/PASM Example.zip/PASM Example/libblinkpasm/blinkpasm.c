#include "simpletools.h"                               // Libary includes
#include "blinkpasm.h"

blink_t *blinkpasm_start(int ledPin,                   // Start LED button cog
                           int cycleTicks)
{
  blink_t *device;                                     // Declare buttonblink pointer
  device = (void *) malloc(sizeof(blink_t));           // Allocate memory for it

  device->maskLed = 1 << ledPin;                       // Info to shared variables
  device->stateLed = 0;
  blinkpasm_setRate(device, cycleTicks);
  if(device->cog == 0)                                 // If cog not already started
  {                                                    // <- Block modified
    extern int binary_BlinkPASM_dat_start[];
    device->cog = 1 + cognew((void*)binary_BlinkPASM_dat_start, (void*)device);
  }
  return device;                                       // Return pointer to structure
}

void blinkpasm_stop(blink_t *device)                   // Stop LED button cog
{
  if(device->cog > 0)                                  // If cog running
  {
    cogstop(device->cog - 1);                          // Shut down cog
    device->cog = 0;                                   // Clear cog varaible
    free(device);                                      // Release allocated memory
  }  
}

int blinkpasm_getState(blink_t *device)                // Get button state
{                                                      // stateButton auto-updated by cog
  return device->stateLed;                             // Return stateButton's value
}

void blinkpasm_setRate(blink_t *device,                 // Set blink period
                      int cycleTicks)                
{                                                      // timeBlink monitored by cog
  device->halfPeriod = cycleTicks / 2;                 // Update timeBlink
}


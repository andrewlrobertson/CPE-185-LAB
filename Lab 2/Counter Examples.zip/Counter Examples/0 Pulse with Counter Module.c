/*
  0 Pulse with Counter Module.c
  
  Set up counter module to NCO mode.  This ties the I/O pin
  to the counter module's phase register's most significant bit.
  
  Propeller Manual Pages 96, 98
  
  PE Kit Labs text, PG 162,
    Negative values will keep the output high.  Use fractions of
    CLKFRQ to control pulse time.
*/

#include <propeller.h>

#define CTR_NCO 0b00100 << 26

int main()
{
  CTRA = CTR_NCO | 27;
  FRQA = 1;
  DIRA |= (1 << 27);
  
  while(1)
  {
    PHSA = -(CLKFREQ/2);
    waitcnt(CLKFREQ + CNT);
  }    
}


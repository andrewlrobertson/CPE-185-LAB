/*
  1 Clock Rate with Counter Module.c
  
  Set up counter module to deliver numerically controlled oscillator 
  frequency.  This example transmits 3 Hz.
  
  Propeller Manual Pages 96, 98
  
  PE Kit Labs text, PG 143:
    Use frq = phs bit 31 frequency * 2^32 / CLKFREQ
*/

#include <propeller.h>

#define CTR_NCO 0b00100 << 26

int main()
{
  DIRA |= (1 << 27);
  FRQA = 3 * ((1 << 31) / (CLKFREQ/2));
  CTRA = CTR_NCO | 27;
  
  while(1);
}


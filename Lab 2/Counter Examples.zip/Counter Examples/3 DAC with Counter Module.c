/*
  3 Dac with Counter Module.c
  
  Propeller Manual Pages 96, 98
  
  PE Kit Labs text, PG 136..138:
    Use frq = some fraction of 2^32 for some fraction of 3.3 V.
*/

#include <propeller.h>                      

#define CTR_DUTY_SE 0b00110 << 26             // Duty single ended
#define DAC_LSB 1 << (32 - 8)                 // 2^32 / 2^8

int main()                                    // Main function
{
  CTRB = CTR_DUTY_SE | 26;                    // Counter B -> duty SE
  FRQB = 0 * DAC_LSB;                         // Output to 0 V
  DIRA |= (1 << 26);                          // I/O to output
    
  int dacVal = 0;                             // Start dacVal at 0
  int incDec = 1;                             // Start incDec at 1
  
  while(1)                                    // Main loop
  {
    if(dacVal >= 255 ) incDec = -1;           // 0 <= dacVal <= 255
    if(dacVal <= 0) incDec = 1;
    dacVal += incDec;                         // dacVal +/- 1
    FRQB = dacVal * DAC_LSB;                  // Set dac output
    waitcnt(CLKFREQ/200 + CNT);               // Repeat after 1/200 s
  }      
}


/*
  2a Dac with abvolts Library.c
  
  Use abvolts library to do D/A
*/

#include "simpletools.h"                     // Library includes
#include "abvolts.h"                      

int main()                                   // Main function
{
  da_out(0, 100);                            // Ch0, 100/256 of 3.3 V 
  pause(2000);                               // ..for 2 s
  da_out(0, 170);                            // Ch0, 170/256 of 3.3 V
  while(1);                                  // ..until reset
}


/*
  1 Clock Rate with freqout function.c
  
  The freqout funciont uses CTR_NCO mode.
*/

#include "simpletools.h"

int main()
{
  freqout(27, 2000, 3);

  while(1);
}


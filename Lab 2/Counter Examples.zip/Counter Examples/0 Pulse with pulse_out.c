/*
  0 Pulse with pulse_out.c
  
  The pulse_out function uses a counter module in NCO mode
  to generate pulses.
*/

#include "simpletools.h"

int main()
{
  while(1)
  {
    pulse_out(26, 500000);
    pause(1000);
  }    
}


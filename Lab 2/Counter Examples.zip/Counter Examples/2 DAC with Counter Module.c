/*
  3 Dac with Counter Module.c
  
  Propeller Manual Pages 96, 98
  
  PE Kit Labs text, PG 136..138:
    Use frq = some fraction of 2^32 for some fraction of 3.3 V.
*/

#include <propeller.h>                      

#define CTR_DUTY_SE 0b00110 << 26             // Duty single ended
#define DAC_LSB 1 << (32 - 8)                 // 2^32 / 2^8

int main()                                    // Main function
{
  CTRB = CTR_DUTY_SE | 26;                    // Counter B -> duty SE, P26
  FRQB = 100 * DAC_LSB;                       // Output to 0 V
  DIRA |= (1 << 26);                          // I/O to output
    
  waitcnt(CLKFREQ*2 + CNT);                   // Wait 2 s
  
  FRQB = 170 * DAC_LSB;                       // Output to 0 V
  
  while(1);                                   // Keep processor running
}

